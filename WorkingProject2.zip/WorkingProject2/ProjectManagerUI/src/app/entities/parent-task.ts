
export interface ParenTask {
    Parent_ID:number;
    Parent_Name:string;

  }