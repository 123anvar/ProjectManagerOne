
export interface Project {
  Project_ID,NumberOfTask?,Manager_ID?,Priority?: number;
  ProjectName?,Status?,Manager_Name?: string;
  Start_Date?,End_Date? :string;
}