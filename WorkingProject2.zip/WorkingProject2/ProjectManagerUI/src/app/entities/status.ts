import { Injectable } from '@angular/core';

export interface Status {
  Result: boolean;
  Message: string;
}